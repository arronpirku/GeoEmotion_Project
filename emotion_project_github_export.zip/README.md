# Emotion Classification Project — GitHub Export

  This export contains only the *lightweight, GitHub-safe* files:
  - training summaries
  - quantization summaries
  - HPO results and plots
  - all configs (HPO grid, label mappings)
  - notebooks

  Model weights and checkpoints are intentionally excluded.

  To fully reproduce the project, place your model directories into:

  final_models/<model_name>/

  And run the provided notebooks.

  ---
  Generated automatically by the GitHub export tool.